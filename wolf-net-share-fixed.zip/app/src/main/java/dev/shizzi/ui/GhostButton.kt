package dev.shizzi.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import dev.shizzi.ui.theme.ShizziTheme
import dev.shizzi.ui.theme.themedLabel
import dev.shizzi.ui.theme.themedIndication
import dev.shizzi.ui.theme.isPressed

@Composable
fun GhostButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isActive: Boolean = false,
    padding: Dp = ShizziTheme.spacing.md,
) {
    val interaction = remember { MutableInteractionSource() }
    val colors = ShizziTheme.colors

    Box(
        modifier = modifier
            .height(ShizziTheme.spacing.xxl)
            .clickable(
                interactionSource = interaction,
                indication = themedIndication(),
                onClick = onClick,
            )
            .padding(horizontal = padding),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = themedLabel(label),
            style = ShizziTheme.typography.caption,
            color = when {
                isActive || interaction.isPressed() -> colors.onSurface
                else -> colors.onSurfaceMuted
            },
        )
    }
}
